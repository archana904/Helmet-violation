"""Answers questions about vehicle and person tracking."""
class TrackingBot:
    keywords = ("track", "tracking", "botsort", "bike", "bicycle",
                "motorcycle", "person", "rider", "walking", "moving", "sitting")

    def can_handle(self, message):
        return any(word in message for word in self.keywords)

    def respond(self, message, context=None):
        return (
            "The project uses YOLO object detection together with BoT-SORT "
            "tracking to maintain object identities across video frames. "
            "Bike/person association and rider-state classification depend on "
            "the implemented pipeline; tracking IDs alone do not prove that "
            "a person is riding or sitting."
        )
