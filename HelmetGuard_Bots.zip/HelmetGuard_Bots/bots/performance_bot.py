"""Answers questions about runtime and hardware performance."""
class PerformanceBot:
    keywords = ("performance", "cpu", "gpu", "fps", "speed", "latency",
                "inference", "memory", "ram", "time")

    def can_handle(self, message):
        return any(word in message for word in self.keywords)

    def respond(self, message, context=None):
        context = context or {}
        if "fps" in context or "avg_ms_per_frame" in context:
            parts = []
            if "fps" in context:
                parts.append(f"FPS: {context['fps']}")
            if "avg_ms_per_frame" in context:
                parts.append(f"average time per frame: {context['avg_ms_per_frame']} ms")
            return "Latest supplied benchmark — " + "; ".join(parts)
        return (
            "Performance is evaluated using FPS and average inference time per "
            "frame, along with CPU/RAM usage where measured. The recorded "
            "YOLO11s-only CPU video benchmark was 9.50 FPS and 105.21 ms/frame. "
            "This is not a full-pipeline benchmark. GPU performance was not "
            "measured on the CPU-only test system."
        )
