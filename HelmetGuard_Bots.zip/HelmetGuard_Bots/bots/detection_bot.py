"""Answers questions about helmet detection."""
class DetectionBot:
    keywords = ("helmet", "violation", "with helmet", "without helmet",
                "confidence", "yolo", "detect")

    def can_handle(self, message):
        return any(word in message for word in self.keywords)

    def respond(self, message, context=None):
        context = context or {}
        count = context.get("helmet_detections")
        if count is not None and any(w in message.lower() for w in ("how many", "count", "number")):
            return f"The latest processed result contains {count} helmet detections."
        return (
            "Helmet detection uses the custom YOLO11 model to classify detected "
            "head regions as 'With Helmet' or 'Without Helmet'. A violation is "
            "flagged when the model predicts 'Without Helmet'. Confidence is "
            "the model's confidence score, not a guarantee that the prediction is correct."
        )
