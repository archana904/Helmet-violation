# HelmetGuard role-based bots

This folder contains a small **rule-based** Python bot system for the
HelmetGuard AI helmet-detection project. It does not use an AI API or an LLM.

## Files

- `bot.py` — main controller; routes questions to the role bots.
- `detection_bot.py` — helmet detection and violation explanations.
- `tracking_bot.py` — bike/person tracking and BoT-SORT explanations.
- `analytics_bot.py` — analytics and run-statistics explanations.
- `performance_bot.py` — CPU/GPU, FPS and inference-time explanations.
- `help_bot.py` — general project and website usage help.

## Requirements

Python 3.9 or newer. No third-party packages are required.

## Run

Open PowerShell in this `bots` folder and run:

```powershell
python bot.py
```

Type `exit` to stop.

## Important integration note

This is a standalone starter version. It does not connect to Flask or the
React website automatically. To show actual run statistics, pass backend
values as the `context` dictionary to `HelmetGuardBot.get_response()`.
For example:

```python
assistant.get_response(
    "How many detections?",
    {"helmet_detections": 12, "frames_processed": 1052}
)
```

The bot must only report real values supplied by the application. It should
not invent detection counts or claim features are implemented when they are
not.
