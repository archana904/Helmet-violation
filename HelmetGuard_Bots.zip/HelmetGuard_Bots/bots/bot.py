"""Main controller for the HelmetGuard role-based bot system.

Run:
    python bot.py

This is a rule-based assistant (not an AI/LLM bot). It routes user questions
to the relevant role bot. Detection statistics are only reported when supplied
by the application; this demo does not invent live detection results.
"""
from detection_bot import DetectionBot
from tracking_bot import TrackingBot
from analytics_bot import AnalyticsBot
from performance_bot import PerformanceBot
from help_bot import HelpBot


class HelmetGuardBot:
    def __init__(self):
        self.bots = [
            DetectionBot(),
            TrackingBot(),
            AnalyticsBot(),
            PerformanceBot(),
            HelpBot(),
        ]

    def get_response(self, message, context=None):
        message = (message or "").strip()
        if not message:
            return "Please enter a question about HelmetGuard AI."

        lowered = message.lower()
        if lowered in {"hi", "hello", "hey", "hai"}:
            return ("Hello! I am HelmetGuard Assistant. Ask me about helmet "
                    "detection, tracking, analytics, performance, or how to use the website.")

        for bot in self.bots:
            if bot.can_handle(lowered):
                return bot.respond(message, context or {})

        return ("I can help with helmet detection, bike/person tracking, "
                "analytics, CPU performance, and website usage. "
                "Please ask a question about one of these topics.")


def main():
    assistant = HelmetGuardBot()
    print("HelmetGuard Assistant (rule-based)")
    print("Type 'exit' to stop.\n")
    while True:
        question = input("You: ").strip()
        if question.lower() in {"exit", "quit"}:
            print("Bot: Goodbye!")
            break
        print("Bot:", assistant.get_response(question))


if __name__ == "__main__":
    main()
