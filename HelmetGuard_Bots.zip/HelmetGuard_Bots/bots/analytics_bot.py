"""Answers questions about analysis and detection statistics."""
class AnalyticsBot:
    keywords = ("analytics", "statistics", "statistic", "total", "count",
                "how many", "report", "results", "precision", "recall", "map")

    def can_handle(self, message):
        return any(word in message for word in self.keywords)

    def respond(self, message, context=None):
        context = context or {}
        keys = ("frames_processed", "helmet_detections",
                "with_helmet", "without_helmet")
        available = {key: context[key] for key in keys if key in context}
        if available:
            summary = ", ".join(f"{key.replace('_', ' ')}: {value}"
                                for key, value in available.items())
            return "Available results from the latest run — " + summary
        return (
            "Analytics can summarize processed frames and helmet detections. "
            "No live run statistics were supplied to this bot yet, so I cannot "
            "give a current count. Connect the backend result values to this bot "
            "to display real statistics."
        )
