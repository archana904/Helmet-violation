"""Answers general questions about using the HelmetGuard website."""
class HelpBot:
    keywords = ("help", "website", "upload", "video", "start", "how to use",
                "dashboard", "page", "project", "what is")

    def can_handle(self, message):
        return any(word in message for word in self.keywords)

    def respond(self, message, context=None):
        return (
            "To use HelmetGuard AI, open the website, go to Upload Video, "
            "choose a supported video, and start processing. When processing "
            "finishes, review the output and available analytics. The exact "
            "buttons and pages depend on the current frontend implementation."
        )
